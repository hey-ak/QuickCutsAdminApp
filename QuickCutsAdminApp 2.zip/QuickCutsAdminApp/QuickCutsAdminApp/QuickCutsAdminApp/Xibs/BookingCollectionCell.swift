//
//  BookingCollectionCell.swift
//  Quick Cuts
//
//  Created by Amit Kumar Dhal on 21/04/24.
//

import UIKit

class BookingCollectionCell: UICollectionViewCell {

    
    @IBOutlet weak var RescheduleButton: UIButton!
    
    @IBOutlet weak var cancelServiceButton: UIButton!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
}
