//
//  CentreCollectionViewCell.swift
//  Quick Cuts
//
//  Created by Neeraj Sharma on 29/04/24.
//

import UIKit

class CentreCollectionViewCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
