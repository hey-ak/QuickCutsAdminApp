//
//  ViewController.swift
//  QuickCutsAdminApp
//
//  Created by Neeraj Sharma on 01/05/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

