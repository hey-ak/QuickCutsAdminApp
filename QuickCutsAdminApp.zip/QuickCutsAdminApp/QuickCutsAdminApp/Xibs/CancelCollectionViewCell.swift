//
//  CancelCollectionViewCell.swift
//  QuickCutsAdminApp
//
//  Created by Akshat Gulati on 07/05/24.
//

import UIKit

class CancelCollectionViewCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
