//
//  MenuCollectionViewCell.swift
//  QuickCutsAdminApp
//
//  Created by Akshat Gulati on 07/05/24.
//

import UIKit

class MenuCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var menuServiceName: UIButton!
    
    @IBOutlet weak var menuServiceCost: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
