
import UIKit

class TimeSlotCollectionCell: UICollectionViewCell {

    @IBOutlet weak var timeSlotLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
}
